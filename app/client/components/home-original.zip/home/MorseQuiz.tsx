import * as React from "react";
import { useEffect, useRef, useState } from "react";

function MorseStats({ morse, wpm }: { morse: string; wpm: number }) {
  // --- calculate Morse timing units and estimated duration ---
  const calculateMorseUnits = (morse: string) => {
    let units = 0;
    let symbols = 0;
    const chars = morse.trim().split("");

    for (let i = 0; i < chars.length; i++) {
      const c = chars[i];
      if (c === ".") {
        units += 1;
        symbols++;
      } else if (c === "-") {
        units += 3;
        symbols++;
      } else if (c === " ") {
        // detect multiple spaces (letter/word gap)
        const spaceCount = morse.slice(i).match(/^ +/)?.[0].length || 1;
        if (spaceCount >= 7) units += 7;
        else if (spaceCount >= 3) units += 3;
        else units += 1;
        i += spaceCount - 1;
      }
    }

    return { units, symbols };
  };

  const { units, symbols } = calculateMorseUnits(morse);
  const dotDuration = 1200 / wpm; // ms per dot
  const totalMs = Math.round(units * dotDuration);
  const seconds = (totalMs / 1000).toFixed(2);

  // --- render UI ---
  return (
    <div className="flex flex-wrap items-center gap-3 text-sm bg-gray-50 px-3 py-2 rounded-md border border-gray-200 mt-3">
      <span className="font-semibold text-[#0b2447]">{symbols}</span> symbols •
      <span className="font-semibold text-[#0b2447]">{units}</span> units • ≈{" "}
      <span className="font-semibold text-[#0b2447]">{seconds}</span> s @ {wpm}{" "}
      WPM
    </div>
  );
}

const pairs = [
  { letter: "A", morse: ".-" },
  { letter: "B", morse: "-..." },
  { letter: "C", morse: "-.-." },
  { letter: "D", morse: "-.." },
  { letter: "E", morse: "." },
  { letter: "F", morse: "..-." },
  { letter: "G", morse: "--." },
  { letter: "H", morse: "...." },
  { letter: "I", morse: ".." },
  { letter: "J", morse: ".---" },
  { letter: "K", morse: "-.-" },
  { letter: "L", morse: ".-.." },
  { letter: "M", morse: "--" },
  { letter: "N", morse: "-." },
  { letter: "O", morse: "---" },
  { letter: "P", morse: ".--." },
  { letter: "Q", morse: "--.-" },
  { letter: "R", morse: ".-." },
  { letter: "S", morse: "..." },
  { letter: "T", morse: "-" },
  { letter: "U", morse: "..-" },
  { letter: "V", morse: "...-" },
  { letter: "W", morse: ".--" },
  { letter: "X", morse: "-..-" },
  { letter: "Y", morse: "-.--" },
  { letter: "Z", morse: "--.." },

  // Digits
  { letter: "0", morse: "-----" },
  { letter: "1", morse: ".----" },
  { letter: "2", morse: "..---" },
  { letter: "3", morse: "...--" },
  { letter: "4", morse: "....-" },
  { letter: "5", morse: "....." },
  { letter: "6", morse: "-...." },
  { letter: "7", morse: "--..." },
  { letter: "8", morse: "---.." },
  { letter: "9", morse: "----." },

  // Punctuation
  { letter: ".", morse: ".-.-.-" },
  { letter: ",", morse: "--..--" },
  { letter: "?", morse: "..--.." },
  { letter: "'", morse: ".----." },
  { letter: "!", morse: "-.-.--" },
  { letter: "/", morse: "-..-." },
  { letter: "(", morse: "-.--." },
  { letter: ")", morse: "-.--.-" },
  { letter: "&", morse: ".-..." },
  { letter: ":", morse: "---..." },
  { letter: ";", morse: "-.-.-." },
  { letter: "=", morse: "-...-" },
  { letter: "+", morse: ".-.-." },
  { letter: "-", morse: "-....-" },
  { letter: "_", morse: "..--.-" },
  { letter: '"', morse: ".-..-." },
  { letter: "$", morse: "...-..-" },
  { letter: "@", morse: ".--.-." },

  // Greetings
  { text: "HELLO", morse: "....   .   .-..   .-..   ---" },
  { text: "HI", morse: "....   .." },
  { text: "HEY", morse: "....   .   -.--" },
  { text: "WELCOME", morse: ".--   .   .-..   -.-.   ---   --   ." },
  {
    text: "GOOD MORNING",
    morse: "--.   ---   ---   -..       --   ---   .-.   -.   ..   -.   --.",
  },
  {
    text: "GOOD NIGHT",
    morse: "--.   ---   ---   -..       -.   ..   --.   ....   -",
  },

  // Courtesy
  { text: "PLEASE", morse: ".--.   .-..   .   .-   ...   ." },
  {
    text: "THANK YOU",
    morse: "-   ....   .-   -.   -.-       -.--   ---   ..-",
  },
  { text: "SORRY", morse: "...   ---   .-.   .-.   -.--" },
  { text: "YES", morse: "-.--   .   ..." },
  { text: "NO", morse: "-.   ---" },
  { text: "MAYBE", morse: "--   .-   -.--   -...   ." },

  // Everyday
  {
    text: "HOW ARE YOU",
    morse: "....   ---   .--       .-   .-.   .       -.--   ---   ..-",
  },
  {
    text: "I LOVE YOU",
    morse: "..       .-..   ---   ...-   .       -.--   ---   ..-",
  },
  { text: "THANKS", morse: "-   ....   .-   -.   -.-   ..." },
  { text: "BYE", morse: "-...   -.--   ." },
  { text: "SEE YOU", morse: "...   .   .       -.--   ---   ..-" },

  // Emotions
  { text: "HAPPY", morse: "....   .-   .--.   .--.   -.--" },
  { text: "SAD", morse: "...   .-   -.." },
  { text: "LOVE", morse: ".-..   ---   ...-   ." },
  { text: "PEACE", morse: ".--.   .   .-   -.-.   ." },

  // Emergencies
  { text: "SOS", morse: "...   ---   ..." },
  { text: "HELP", morse: "....   .   .-..   .--." },
  { text: "EMERGENCY", morse: ".   --   .   .-.   --.   .   -.   -.-.   -.--" },
  { text: "STOP", morse: "...   -   ---   .--." },
  { text: "FIRE", morse: "..-.   ..   .-.   ." },
  {
    text: "CALL 911",
    morse: "-.-.   .-   .-..   .-..       ----.   .----   .----",
  },

  // Nouns
  { text: "DOG", morse: "-..   ---   --." },
  { text: "CAT", morse: "-.-.   .-   -" },
  { text: "TREE", morse: "-   .-.   .   ." },
  { text: "SUN", morse: "...   ..-   -." },
  { text: "MOON", morse: "--   ---   ---   -." },
  { text: "STAR", morse: "...   -   .-   .-." },

  // Numbers & time
  {
    text: "ONE TWO THREE",
    morse: "---   -.   .       -   .--   ---       -   ....   .-.   .   .",
  },
  { text: "123", morse: ".----   ..---   ...--" },
  { text: "2025", morse: "..---   -----   ..---   ....." },
  { text: "TIME", morse: "-   ..   --   ." },

  // Radio procedure
  { text: "CQ", morse: "-.-.   --.-" },
  { text: "OVER", morse: "---   ...-   .   .-." },
  { text: "OUT", morse: "---   ..-   -" },
  { text: "WAIT", morse: ".--   .-   ..   -" },
  { text: "READY", morse: ".-.   .   .-   -..   -.--" },
  { text: "GO", morse: "--.   ---" },

  // Learning
  { text: "CODE", morse: "-.-.   ---   -..   ." },
  { text: "MORSE", morse: "--   ---   .-.   ...   ." },
  { text: "LEARN", morse: ".-..   .   .-   .-.   -." },
  { text: "QUIZ", morse: "--.-   ..-   ..   --.." },
  { text: "PRACTICE", morse: ".--.   .-.   .-   -.-.   -   ..   -.-.   ." },

  // Emergency phrases
  { text: "MAYDAY", morse: "--   .-   -.--   -..   .-   -.--" },
  {
    text: "SOS HELP ME",
    morse: "...   ---   ...       ....   .   .-..   .--.       --   .",
  },
  { text: "FIRE HERE", morse: "..-.   ..   .-.   .       ....   .   .-.   ." },
  {
    text: "NEED ASSISTANCE",
    morse:
      "-.   .   .   -..       .-   ...   ...   ..   ...   -   .-   -.   -.-.   .",
  },

  // Love
  {
    text: "I MISS YOU",
    morse: "..       --   ..   ...   ...       -.--   ---   ..-",
  },
  { text: "BE MINE", morse: "-...   .       --   ..   -.   ." },
  { text: "LOVE YOU", morse: ".-..   ---   ...-   .       -.--   ---   ..-" },

  { text: "GOOD JOB", morse: "--.   ---   ---   -..       .---   ---   -..." },
  {
    text: "WELL DONE",
    morse: ".--   .   .-..   .-..       -..   ---   -.   .",
  },
  {
    text: "NICE WORK",
    morse: "-.   ..   -.-.   .       .--   ---   .-.   -.-",
  },
  {
    text: "KEEP GOING",
    morse: "-.-   .   .   .--.       --.   ---   ..   -.   --.",
  },
  {
    text: "STAY STRONG",
    morse: "...   -   .-   -.--       ...   -   .-.   ---   -.   --.",
  },
  { text: "TRY AGAIN", morse: "-   .-.   -.--       .-   --.   .-   ..   -." },
  { text: "YOU CAN", morse: "-.--   ---   ..-       -.-.   .-   -." },
  {
    text: "GREAT WORK",
    morse: "--.   .-.   .   .-   -       .--   ---   .-.   -.-",
  },
  {
    text: "KEEP LEARNING",
    morse: "-.-   .   .   .--.       .-..   .   .-   .-.   -.   ..   -.   --.",
  },

  {
    text: "NEVER QUIT",
    morse: "-.   .   ...-   .   .-.       --.-   ..-   ..   -",
  },
  { text: "BE STRONG", morse: "-...   .       ...   -   .-.   ---   -.   --." },
  {
    text: "KEEP TRYING",
    morse: "-.-   .   .   .--.       -   .-.   -.--   ..   -.   --.",
  },
  { text: "BELIEVE", morse: "-...   .   .-..   ..   .   ...-   ." },
  { text: "FOCUS", morse: "..-.   ---   -.-.   ..-   ..." },
  { text: "SMILE", morse: "...   --   ..   .-..   ." },
  { text: "WIN", morse: ".--   ..   -." },
  {
    text: "READY SET GO",
    morse: ".-.   .   .-   -..   -.--       ...   .   -       --.   ---",
  },

  {
    text: "HELLO THERE",
    morse: "....   .   .-..   .-..   ---       -   ....   .   .-.   .",
  },
  {
    text: "HI FRIEND",
    morse: "....   ..       ..-.   .-.   ..   .   -.   -..",
  },
  {
    text: "SECRET CODE",
    morse: "...   .   -.-.   .-.   .   -       -.-.   ---   -..   .",
  },
  {
    text: "HIDDEN MESSAGE",
    morse:
      "....   ..   -..   -..   .   -.       --   .   ...   ...   .-   --.   .",
  },
  {
    text: "RADIO SIGNAL",
    morse: ".-.   .-   -..   ..   ---       ...   ..   --.   -.   .-   .-..",
  },
  { text: "TAP TAP", morse: "-   .-   .--.       -   .-   .--." },
  { text: "FUN TIME", morse: "..-.   ..-   -.       -   ..   --   ." },
  { text: "CODE GAME", morse: "-.-.   ---   -..   .       --.   .-   --   ." },

  { text: "ALERT", morse: ".-   .-..   .   .-.   -" },
  { text: "SAFE NOW", morse: "...   .-   ..-.   .       -.   ---   .--" },
  {
    text: "HELP NEEDED",
    morse: "....   .   .-..   .--.       -.   .   .   -..   .   -..",
  },
  {
    text: "ALL CLEAR",
    morse: ".-   .-..   .-..       -.-.   .-..   .   .-   .-.",
  },
  {
    text: "CALL FOR HELP",
    morse:
      "-.-.   .-   .-..   .-..       ..-.   ---   .-.       ....   .   .-..   .--.",
  },
];

function MorseQuiz() {
  // ----- helpers -----
  const getAnswerFromPair = (p: any): string =>
    (p?.letter ?? p?.text ?? p?.word ?? p?.char ?? p?.label ?? "")
      .toString()
      .trim()
      .toUpperCase();

  const getMorseFromPair = (p: any): string => (p?.morse ?? "").toString();

  const normalizeText = (s: string): string =>
    s.replace(/\s+/g, " ").trim().toUpperCase();

  // ensure we only pick items that have morse and some answer text
  const validPairs = Array.isArray(pairs)
    ? pairs.filter((p) => getMorseFromPair(p) && getAnswerFromPair(p))
    : [];

  if (validPairs.length === 0) {
    console.warn("⚠️ No valid pairs available");
    return (
      <div className="border border-gray-200 rounded-xl p-6 bg-white mt-8 text-gray-700">
        Loading quiz…
      </div>
    );
  }

  const getRandomPair = () =>
    validPairs[Math.floor(Math.random() * validPairs.length)] ?? validPairs[0];

  // ----- state -----
  const [question, setQuestion] = useState<any>(null);
  const [answer, setAnswer] = useState("");
  const [feedback, setFeedback] = useState("");
  const [streak, setStreak] = useState(0);
  const [focused, setFocused] = useState(false);
  const [locked, setLocked] = useState(false);

  const timeoutRef = useRef<number | null>(null);
  const inputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    // initialize once on client
    if (!question && validPairs.length > 0) {
      setQuestion(getRandomPair());
    }
  }, [question, validPairs]);

  // ----- submit -----
  const handleSubmit = () => {
    if (locked) return;

    const user = normalizeText(answer);
    if (!user) return;

    // snapshot current question to avoid race conditions
    const current = question;
    const expected = normalizeText(getAnswerFromPair(current));

    setLocked(true);

    if (user === expected) {
      setFeedback("✅ Correct!");
      setStreak((s) => s + 1);
    } else {
      // show the *resolved* expected string (letter OR word)
      setFeedback(`❌ The correct answer was “${expected || "?"}”.`);
      setStreak(0);
    }

    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
      timeoutRef.current = null;
    }

    timeoutRef.current = window.setTimeout(() => {
      setQuestion(getRandomPair());
      setAnswer("");
      setFeedback("");
      setLocked(false);
      inputRef.current?.focus();
    }, 1800);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter") {
      e.preventDefault();
      handleSubmit();
    }
  };

  useEffect(() => {
    return () => {
      if (timeoutRef.current) clearTimeout(timeoutRef.current);
    };
  }, []);

  // ----- render -----
  const morse = question ? getMorseFromPair(question) : "";

  return (
    <section
      className="border border-gray-200 rounded-2xl p-6 mt-8 bg-white mb-5 space-y-5 shadow-sm transition"
      aria-labelledby="morse-quiz-title"
      itemScope
      itemType="https://schema.org/Quiz"
    >
      <h2
        id="morse-quiz-title"
        itemProp="name"
        className="font-bold text-2xl text-[#0b2447]"
      >
        Morse Code Quick Quiz - Test Your Skills & Beat Your Longest Streak!
      </h2>

      <p
        itemProp="description"
        className="text-gray-700 text-base leading-relaxed"
      >
        Decode the Morse code shown below by typing the matching{" "}
        <strong>letter or word</strong>. Press <kbd>Enter</kbd> or click{" "}
        <strong>Check</strong> to submit. Build your streak!
      </p>

      <div
        className="flex flex-col items-start gap-4 mt-2"
        itemProp="hasPart"
        itemScope
        itemType="https://schema.org/Question"
      >
        <p className="text-lg text-gray-800">
          <span className="font-semibold text-[#0b2447]">Code:</span>{" "}
          <span
            itemProp="text"
            className="font-mono text-2xl tracking-wider select-none bg-gray-50 px-3 py-1 rounded"
          >
            {morse || "…"}
          </span>
        </p>

        <div className="flex flex-col sm:flex-row w-full items-center gap-3">
          <label htmlFor="quizAnswer" className="sr-only">
            Enter your answer
          </label>

          <input
            ref={inputRef}
            id="quizAnswer"
            type="text"
            className="border border-gray-300 rounded-md w-full sm:w-2/3 px-4 py-2 text-base text-gray-900 text-left font-medium focus:ring-2 focus:ring-[#0b2447] outline-none transition"
            placeholder={focused ? "" : "Type your answer (letter or word)"}
            value={answer}
            onFocus={() => setFocused(true)}
            onBlur={() => setFocused(false)}
            onChange={(e) => setAnswer(e.target.value)}
            onKeyDown={handleKeyDown}
            aria-label="Your answer"
            disabled={locked}
            autoCapitalize="characters"
          />

          <button
            onClick={handleSubmit}
            className={`px-6 py-2 cursor-pointer rounded-md font-semibold transition text-white ${
              locked
                ? "bg-gray-400 cursor-not-allowed"
                : "bg-[#0b2447] hover:bg-[#09203d] active:scale-95"
            }`}
            disabled={locked}
            itemProp="suggestedAnswer"
            itemScope
            itemType="https://schema.org/Answer"
          >
            {locked ? "Next…" : "Check"}
          </button>
        </div>

        {feedback && (
          <p
            className={`text-base font-semibold mt-1 ${
              feedback.startsWith("✅") ? "text-green-600" : "text-red-600"
            }`}
            itemProp="acceptedAnswer"
            itemScope
            itemType="https://schema.org/Answer"
          >
            <span itemProp="text">{feedback}</span>
          </p>
        )}

        <div className="text-sm text-gray-600 flex flex-wrap gap-3 mt-2">
          <span>🔥 Streak: {streak}</span>
          <span className="hidden sm:inline">•</span>
          <span>New code appears automatically after each answer.</span>
        </div>
      </div>
    </section>
  );
}


export default MorseQuiz;
