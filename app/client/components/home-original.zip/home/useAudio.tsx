import * as React from "react";

export default function useAudio() {
  const ctxRef = React.useRef<AudioContext | null>(null);
  const stopRef = React.useRef(false);

  function ditMs(wpm: number) {
    return 1200 / wpm;
  }
  const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

  async function tone(ms: number, hz: number) {
    if (!ctxRef.current)
      ctxRef.current = new (window.AudioContext ||
        (window as any).webkitAudioContext)();
    const ctx = ctxRef.current;
    if (!ctx) return;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = "sine";
    osc.frequency.value = hz;
    gain.gain.value = 0.001;
    osc.connect(gain).connect(ctx.destination);
    osc.start();
    const now = ctx.currentTime;
    gain.gain.exponentialRampToValueAtTime(0.25, now + 0.01);
    await sleep(ms);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.01);
    await sleep(14);
    osc.stop();
  }

  async function playMorse(
    code: string,
    wpm: number,
    hz: number,
    wordGapUnits = 7
  ) {
    stopRef.current = false;
    const unit = ditMs(wpm);
    const parts = code.trim().split(/(\s+)/);
    for (let i = 0; i < parts.length; i++) {
      if (stopRef.current) break;
      const token = parts[i];
      if (/^\s+$/.test(token)) {
        const spaces = token.length;
        const units = spaces >= 7 ? wordGapUnits : spaces >= 3 ? 3 : 1;
        await sleep(units * unit);
        continue;
      }
      for (let s = 0; s < token.length; s++) {
        if (stopRef.current) break;
        const ch = token[s];
        if (ch === ".") await tone(unit, hz);
        else if (ch === "-") await tone(3 * unit, hz);
        if (s < token.length - 1) await sleep(unit);
      }
    }
  }

  function stop() {
    stopRef.current = true;
  }
  return { playMorse, stop };
}
