import * as React from "react";

function MorseLookupTable() {
  const morseData = [
    // Letters
    { symbol: "A", morse: ".-" },
    { symbol: "B", morse: "-..." },
    { symbol: "C", morse: "-.-." },
    { symbol: "D", morse: "-.." },
    { symbol: "E", morse: "." },
    { symbol: "F", morse: "..-." },
    { symbol: "G", morse: "--." },
    { symbol: "H", morse: "...." },
    { symbol: "I", morse: ".." },
    { symbol: "J", morse: ".---" },
    { symbol: "K", morse: "-.-" },
    { symbol: "L", morse: ".-.." },
    { symbol: "M", morse: "--" },
    { symbol: "N", morse: "-." },
    { symbol: "O", morse: "---" },
    { symbol: "P", morse: ".--." },
    { symbol: "Q", morse: "--.-" },
    { symbol: "R", morse: ".-." },
    { symbol: "S", morse: "..." },
    { symbol: "T", morse: "-" },
    { symbol: "U", morse: "..-" },
    { symbol: "V", morse: "...-" },
    { symbol: "W", morse: ".--" },
    { symbol: "X", morse: "-..-" },
    { symbol: "Y", morse: "-.--" },
    { symbol: "Z", morse: "--.." },

    // Numbers
    { symbol: "1", morse: ".----" },
    { symbol: "2", morse: "..---" },
    { symbol: "3", morse: "...--" },
    { symbol: "4", morse: "....-" },
    { symbol: "5", morse: "....." },
    { symbol: "6", morse: "-...." },
    { symbol: "7", morse: "--..." },
    { symbol: "8", morse: "---.." },
    { symbol: "9", morse: "----." },
    { symbol: "0", morse: "-----" },

    // Punctuation
    { symbol: ".", morse: ".-.-.-" },
    { symbol: ",", morse: "--..--" },
    { symbol: "?", morse: "..--.." },
    { symbol: "'", morse: ".----." },
    { symbol: "!", morse: "-.-.--" },
    { symbol: "/", morse: "-..-." },
    { symbol: "(", morse: "-.--." },
    { symbol: ")", morse: "-.--.-" },
    { symbol: "&", morse: ".-..." },
    { symbol: ":", morse: "---..." },
    { symbol: ";", morse: "-.-.-." },
    { symbol: "=", morse: "-...-" },
    { symbol: "+", morse: ".-.-." },
    { symbol: "-", morse: "-....-" },
    { symbol: "_", morse: "..--.-" },
    { symbol: '"', morse: ".-..-." },
    { symbol: "@", morse: ".--.-." },
  ];

  return (
    <section
      className="my-12 border border-gray-200 rounded-2xl bg-white shadow-sm p-6"
      aria-labelledby="morse-table-title"
      itemScope
      itemType="https://schema.org/Table"
    >
      <h2
        id="morse-table-title"
        className="text-2xl font-bold text-[#0b2447] mb-2"
        itemProp="name"
      >
        Morse Code Conversion Table (A–Z, 0–9, and Symbols)
      </h2>
      <p
        className="text-gray-700 text-base leading-relaxed mb-6"
        itemProp="description"
      >
        This complete International Morse Code chart shows letters, numbers, and
        punctuation with their corresponding dot (·) and dash (–) patterns. Use
        it as a quick reference for learning or decoding messages. Perfect for
        radio operators, students, and Morse enthusiasts.
      </p>

      <div className="overflow-x-auto">
        <table
          className="min-w-full border-collapse text-sm md:text-base text-gray-800"
          itemProp="about"
        >
          <thead className="bg-gray-50 border-b">
            <tr>
              <th className="py-2 px-3 text-left font-semibold border-r">
                Character
              </th>
              <th className="py-2 px-3 text-left font-semibold border-r">
                Morse Code
              </th>
              <th className="py-2 px-3 text-left font-semibold">Category</th>
            </tr>
          </thead>
          <tbody>
            {morseData.map((item, idx) => (
              <tr
                key={idx}
                className="odd:bg-white even:bg-gray-50 hover:bg-blue-50 transition"
              >
                <td className="py-2 px-3 font-mono font-semibold">
                  {item.symbol}
                </td>
                <td className="py-2 px-3 font-mono text-[#0b2447] tracking-wider">
                  {item.morse}
                </td>
                <td className="py-2 px-3 text-gray-600">
                  {/[A-Z]/.test(item.symbol)
                    ? "Letter"
                    : /[0-9]/.test(item.symbol)
                      ? "Number"
                      : "Punctuation"}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* SEO-rich paragraph below table */}
      <div className="mt-6 text-sm text-gray-700 leading-relaxed space-y-2">
        <p>
          Each Morse symbol combines dots (·) and dashes (–) with precise
          timing. One dot equals one unit, a dash equals three units, the gap
          between elements within a letter is one unit, between letters is
          three, and between words is seven units.
        </p>
        <p>
          Learning the rhythm of Morse code is key to mastery. Start with the
          most common letters (E, T, A, I, N, O), then progress to numbers and
          punctuation. With regular practice, you’ll be able to recognize entire
          words by sound alone.
        </p>
        <p>
          This chart follows the{" "}
          <strong>ITU International Morse Standard</strong> and is suitable for{" "}
          <em>
            ham radio operators, aviation, maritime use, and educational
            learning
          </em>
          . Bookmark this page as a quick Morse reference anytime you need to
          translate between text and code.
        </p>
      </div>
    </section>
  );
}


export default MorseLookupTable;
