import * as React from "react";

export default function HowItWorksTyping() {
  return (
    <section className="mt-8 bg-white border border-gray-200 rounded-2xl p-5 sm:p-8 shadow-sm">
      <div className="flex flex-col gap-3">
        <div className="inline-flex items-center gap-2">
          <span className="inline-flex items-center rounded-full bg-sky-50 px-3 py-1.5 text-sm font-extrabold text-sky-900 border border-sky-200">
            Typing mode
          </span>
        </div>

        <h2 className="text-3xl sm:text-4xl font-extrabold text-[#0b2447] tracking-tight">
          How this Morse typing scratchpad works
        </h2>

        <p className="text-base sm:text-lg text-gray-700 leading-relaxed">
          <strong>/typing</strong> is built for people who already know Morse and
          want clean repetition. You enter dots and dashes like you would in a
          notebook, commit boundaries, and watch the decoded text build up as you
          go. It stays lightweight on purpose, so you can focus on rhythm and
          endurance instead of prompts or grading.
        </p>
      </div>

      <div className="mt-6 flex flex-wrap gap-2">
        {[
          ["Input keys", "#typing-input"],
          ["Boundaries", "#typing-boundaries"],
          ["Session timer", "#typing-timer"],
          ["Results + sharing", "#typing-results"],
        ].map(([label, href]) => (
          <a
            key={href}
            href={href}
            className="px-3 py-1.5 rounded-full text-sm sm:text-base font-semibold border border-gray-200 bg-white text-gray-700 hover:bg-gray-50 cursor-pointer transition"
          >
            {label}
          </a>
        ))}
      </div>

      <div className="mt-7 grid gap-4 sm:grid-cols-3">
        <div className="rounded-2xl border border-sky-200 bg-sky-50 p-5">
          <p className="text-base font-extrabold text-[#0b2447]">Freeform flow</p>
          <p className="mt-2 text-base sm:text-lg text-gray-700 leading-relaxed">
            There are no questions to answer. You type continuously, backspace
            when you want, and reset when you are ready for a fresh run.
          </p>
        </div>

        <div className="rounded-2xl border border-sky-200 bg-sky-50 p-5">
          <p className="text-base font-extrabold text-[#0b2447]">Instant decode</p>
          <p className="mt-2 text-base sm:text-lg text-gray-700 leading-relaxed">
            Letters decode when you commit a boundary. Anything incomplete stays
            in the current buffer until you end the letter.
          </p>
        </div>

        <div className="rounded-2xl border border-sky-200 bg-sky-50 p-5">
          <p className="text-base font-extrabold text-[#0b2447]">Timed sessions</p>
          <p className="mt-2 text-base sm:text-lg text-gray-700 leading-relaxed">
            Pick a short or long duration, then start typing. The timer begins on
            your first input, and you get a clean summary at the end.
          </p>
        </div>
      </div>

      <div className="mt-8 space-y-6 text-gray-700 leading-relaxed">
        <div id="typing-input" className="rounded-2xl border border-gray-200 p-6 sm:p-7">
          <h3 className="text-xl sm:text-2xl font-extrabold text-[#0b2447]">
            Input keys
          </h3>
          <ul className="mt-4 list-disc pl-6 space-y-3 text-base sm:text-lg">
            <li>
              Type <code className="rounded-md bg-gray-50 px-2 py-1 border border-gray-200">.</code>{" "}
              for dit and{" "}
              <code className="rounded-md bg-gray-50 px-2 py-1 border border-gray-200">-</code>{" "}
              for dah.
            </li>
            <li>
              Optional mapping:{" "}
              <code className="rounded-md bg-gray-50 px-2 py-1 border border-gray-200">F</code>{" "}
              enters a dit and{" "}
              <code className="rounded-md bg-gray-50 px-2 py-1 border border-gray-200">J</code>{" "}
              enters a dah (handy for touch typing).
            </li>
            <li>
              Pasted Morse is accepted too. Common dot and dash lookalikes are
              normalized.
            </li>
          </ul>
        </div>

        <div
          id="typing-boundaries"
          className="rounded-2xl border border-gray-200 p-6 sm:p-7"
        >
          <h3 className="text-xl sm:text-2xl font-extrabold text-[#0b2447]">
            Boundaries and committing letters
          </h3>
          <p className="mt-4 text-base sm:text-lg">
            This tool is boundary-driven. It does not guess where letters end.
            You decide when a letter or word is complete.
          </p>
          <ul className="mt-4 list-disc pl-6 space-y-3 text-base sm:text-lg">
            <li>
              <strong>Space</strong> commits the current Morse chunk as a letter.
            </li>
            <li>
              <strong>/</strong> commits a word break (and also commits any
              pending letter first).
            </li>
            <li>
              If a chunk is not recognized, it shows as{" "}
              <strong>?</strong> so mistakes stay visible.
            </li>
          </ul>
        </div>

        <div id="typing-timer" className="rounded-2xl border border-gray-200 p-6 sm:p-7">
          <h3 className="text-xl sm:text-2xl font-extrabold text-[#0b2447]">
            Session timer
          </h3>
          <ul className="mt-4 list-disc pl-6 space-y-3 text-base sm:text-lg">
            <li>Choose a preset duration (10s up to 30m).</li>
            <li>The countdown starts automatically on your first input.</li>
            <li>
              Use <strong>Pause</strong> to stop the clock without clearing your
              text, or <strong>Reset</strong> to start over.
            </li>
          </ul>
        </div>

        <div
          id="typing-results"
          className="rounded-2xl border border-gray-200 p-6 sm:p-7"
        >
          <h3 className="text-xl sm:text-2xl font-extrabold text-[#0b2447]">
            Results and sharing
          </h3>
          <p className="mt-4 text-base sm:text-lg">
            When the timer ends, input freezes and you get a summary card with
            your session stats. You can share a clean screenshot-style result,
            the same way the Practice page does.
          </p>
          <ul className="mt-4 list-disc pl-6 space-y-3 text-base sm:text-lg">
            <li>Letters and words committed</li>
            <li>Letters per minute</li>
            <li>Invalid commits (unrecognized chunks)</li>
            <li>One tap Share or Download PNG</li>
          </ul>
        </div>
      </div>
    </section>
  );
}
