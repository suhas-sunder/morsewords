export default function HowItWorks() {
  return (
    <section className="mt-6 bg-white border border-gray-200 rounded-2xl p-6 shadow-sm">
      <div className="flex flex-col gap-2">
        <div className="inline-flex items-center gap-2">
          <span className="inline-flex items-center rounded-full bg-sky-50 px-3 py-1 text-xs font-bold text-sky-900 border border-sky-200">
            Translator spec
          </span>
          <span className="text-xs text-gray-600">
            Exact rules this page follows
          </span>
        </div>

        <h2 className="text-2xl font-extrabold text-[#0b2447]">
          How this translator works
        </h2>

        <p className="text-gray-700 leading-relaxed">
          This route is a two-way utility. It converts plain text to
          International Morse, and it converts Morse back to readable text. It
          is built to be predictable: it normalizes inputs, applies a fixed
          character map, and keeps mistakes visible instead of guessing.
        </p>
      </div>

      <div className="mt-6 grid gap-3 sm:grid-cols-3">
        <div className="rounded-xl border border-sky-200 bg-sky-50 p-4">
          <p className="text-sm font-extrabold text-[#0b2447]">
            Spacing legend
          </p>
          <p className="mt-1 text-sm text-gray-700">
            Output uses <strong>3 spaces</strong> between letters and{" "}
            <strong>7 spaces</strong> between words.
          </p>
        </div>
        <div className="rounded-xl border border-sky-200 bg-sky-50 p-4">
          <p className="text-sm font-extrabold text-[#0b2447]">
            Decoder boundaries
          </p>
          <p className="mt-1 text-sm text-gray-700">
            When decoding, <strong>1–6 spaces</strong> separates letters.{" "}
            <strong>7+ spaces</strong>, <strong>/</strong>, and new lines
            separate words.
          </p>
        </div>
        <div className="rounded-xl border border-sky-200 bg-sky-50 p-4">
          <p className="text-sm font-extrabold text-[#0b2447]">
            Errors stay visible
          </p>
          <p className="mt-1 text-sm text-gray-700">
            Unknown Morse chunks decode to <strong>?</strong>. Unsupported text
            characters are skipped and surfaced in the UI.
          </p>
        </div>
      </div>

      <div className="mt-6 space-y-6 text-gray-700 leading-relaxed">
        <div className="rounded-xl border border-gray-200 p-5">
          <h3 className="text-lg font-extrabold text-[#0b2447]">
            Text → Morse
          </h3>
          <ul className="mt-3 list-disc pl-6 space-y-2">
            <li>
              Input text is normalized and uppercased, then each supported
              character is looked up in a fixed International Morse map.
            </li>
            <li>
              Any run of whitespace in the text input is treated as a word
              break. The Morse output is re-emitted with consistent separators.
            </li>
            <li>
              Output formatting is strict: <strong>3 spaces</strong> between
              letters, <strong>7 spaces</strong> between words.
            </li>
            <li>
              Unsupported characters are not invented or approximated. They are
              skipped in the Morse output and listed under the input so you can
              fix the source.
            </li>
          </ul>

          <div className="mt-4">
            <p className="text-sm font-bold text-gray-800">Example</p>
            <pre className="mt-2 whitespace-pre-wrap rounded-xl border border-gray-200 bg-gray-50 p-3 text-sm font-mono">
              HELLO WORLD .... . .-.. .-.. --- .-- --- .-. .-.. -..
            </pre>
            <p className="mt-2 text-sm text-gray-600">
              The spacing is part of the output. If you copy this Morse
              elsewhere, keep the gaps.
            </p>
          </div>
        </div>

        <div className="rounded-xl border border-gray-200 p-5">
          <h3 className="text-lg font-extrabold text-[#0b2447]">
            Morse → Text
          </h3>
          <p className="mt-3">
            Decoding is boundary-driven. The tool does not infer letter breaks
            from timing. It reads chunks of dots and dashes, then uses
            separators to decide where each letter and word ends.
          </p>

          <ul className="mt-3 list-disc pl-6 space-y-2">
            <li>
              Valid Morse characters are dot and dash, plus whitespace and{" "}
              <strong>/</strong> for separation.
            </li>
            <li>
              The decoder normalizes common lookalikes: <strong>· • ∙</strong>{" "}
              become dot, and <strong>– — −</strong> become dash.
            </li>
            <li>
              Separators: <strong>1–6 spaces</strong> means letter gap.{" "}
              <strong>7+ spaces</strong>, <strong>/</strong>, or a new line
              means word gap.
            </li>
            <li>
              If a Morse chunk is not recognized, the output shows{" "}
              <strong>?</strong> so the mistake stays visible and you can
              correct it.
            </li>
          </ul>

          <div className="mt-4">
            <p className="text-sm font-bold text-gray-800">Examples</p>
            <pre className="mt-2 whitespace-pre-wrap rounded-xl border border-gray-200 bg-gray-50 p-3 text-sm font-mono">
              ... --- ... SOS ... / --- / ... S O S
            </pre>
            <p className="mt-2 text-sm text-gray-600">
              Tip: if everything runs together, add separators. The safest
              format is 3 spaces between letters and 7 spaces between words.
            </p>
          </div>
        </div>

        <div className="rounded-xl border border-gray-200 p-5">
          <h3 className="text-lg font-extrabold text-[#0b2447]">
            Input formatting guide
          </h3>
          <div className="mt-3 grid gap-3 sm:grid-cols-2">
            <div className="rounded-xl border border-sky-200 bg-sky-50 p-4">
              <p className="text-sm font-bold text-[#0b2447]">
                For best decoding
              </p>
              <ul className="mt-2 list-disc pl-6 space-y-1 text-sm">
                <li>3 spaces between letters</li>
                <li>7 spaces between words</li>
                <li>/ can replace a word gap</li>
                <li>New lines count as word gaps</li>
              </ul>
            </div>
            <div className="rounded-xl border border-sky-200 bg-sky-50 p-4">
              <p className="text-sm font-bold text-[#0b2447]">
                Common paste problems
              </p>
              <ul className="mt-2 list-disc pl-6 space-y-1 text-sm">
                <li>Fancy dashes from PDFs</li>
                <li>Dots rendered as bullets</li>
                <li>Mixed separators</li>
                <li>Extra punctuation mixed into Morse</li>
              </ul>
            </div>
          </div>
          <p className="mt-4">
            If you need to preserve exact spacing inside a single word, this
            tool will not do that. It favors predictable normalization and
            consistent separators so copied output behaves the same across
            tools.
          </p>
        </div>

        <div className="rounded-xl border border-gray-200 p-5">
          <h3 className="text-lg font-extrabold text-[#0b2447]">
            Supported characters and assumptions
          </h3>
          <p className="mt-3">
            This translator supports A–Z, 0–9, and a core set of common
            punctuation. It intentionally does not guess at extended alphabets
            or locale-specific variants.
          </p>
          <p className="mt-3">
            Supported punctuation includes:{" "}
            <code>. , ? / ' ! - @ : ; = + " ( ) &amp; _</code>.
          </p>

          <div className="mt-4 rounded-xl border border-gray-200 bg-white p-4">
            <p className="text-sm font-bold text-gray-800">Related tools</p>
            <ul className="mt-2 list-disc pl-6 space-y-2 text-sm">
              <li>
                <a
                  href="/audio"
                  className="text-[#0b2447] underline hover:no-underline cursor-pointer"
                >
                  Audio
                </a>{" "}
                for focused playback and timing controls.
              </li>
              <li>
                <a
                  href="/dictionary"
                  className="text-[#0b2447] underline hover:no-underline cursor-pointer"
                >
                  Dictionary
                </a>{" "}
                to look up characters and punctuation.
              </li>
              <li>
                <a
                  href="/practice"
                  className="text-[#0b2447] underline hover:no-underline cursor-pointer"
                >
                  Practice
                </a>{" "}
                and{" "}
                <a
                  href="/typing"
                  className="text-[#0b2447] underline hover:no-underline cursor-pointer"
                >
                  Typing
                </a>{" "}
                for drills and repetition.
              </li>
              <li>
                <a
                  href="/how-to-use"
                  className="text-[#0b2447] underline hover:no-underline cursor-pointer"
                >
                  How to use
                </a>{" "}
                for suite-level notes.
              </li>
            </ul>
          </div>
        </div>

        <div className="rounded-xl border border-gray-200 p-5">
          <h3 className="text-lg font-extrabold text-[#0b2447]">
            Playback and timing
          </h3>
          <p className="mt-3">
            The play button always plays Morse. If you are in Text → Morse mode,
            it plays the generated Morse output. If you are in Morse → Text
            mode, it plays the Morse you pasted, which is useful for checking
            whether your spacing and symbols sound right.
          </p>
          <ul className="mt-3 list-disc pl-6 space-y-2">
            <li>
              <strong>Speed</strong> controls the character rate (WPM). Faster
              WPM makes dots and dashes shorter.
            </li>
            <li>
              <strong>Farnsworth</strong> (when enabled in advanced settings)
              keeps characters crisp while stretching the gaps between them, so
              letters are easier to distinguish without changing their shape.
            </li>
            <li>
              <strong>Pitch</strong> sets the tone frequency. If audio feels
              harsh on small speakers, lower the pitch slightly.
            </li>
            <li>
              <strong>Volume</strong> affects only sound output. Flash and
              vibration can stay enabled even if sound is off.
            </li>
          </ul>
          <p className="mt-3">
            On mobile, some browsers require a user gesture before audio can
            start. If play does nothing, tap play again or toggle the Sound
            button once, then retry.
          </p>
        </div>

        <div className="rounded-xl border border-gray-200 p-5">
          <h3 className="text-lg font-extrabold text-[#0b2447]">
            Troubleshooting
          </h3>
          <ul className="mt-3 list-disc pl-6 space-y-2">
            <li>
              <strong>Decoded text looks wrong:</strong> check boundaries. Add 3
              spaces between letters and 7 spaces between words, or use /
              between words.
            </li>
            <li>
              <strong>You see ? characters:</strong> at least one Morse chunk
              was not recognized. Look for missing dots, extra dashes, or
              accidental characters mixed into the Morse.
            </li>
            <li>
              <strong>Encoding skipped characters:</strong> the unsupported list
              under the input shows exactly what was ignored. Replace those
              characters with supported punctuation or plain letters.
            </li>
            <li>
              <strong>Pasted Morse has weird symbols:</strong> PDFs often
              replace hyphen with a long dash, and dot with a bullet. This tool
              normalizes the most common variants, but anything else will be
              flagged as invalid.
            </li>
            <li>
              <strong>Audio is silent:</strong> confirm Sound is on, raise
              volume, and make sure your device is not muted. If you are using
              Bluetooth, reconnect and try again.
            </li>
          </ul>
        </div>
      </div>
    </section>
  );
}
