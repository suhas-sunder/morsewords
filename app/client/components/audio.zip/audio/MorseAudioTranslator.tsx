import * as React from "react";

import styles from "~/client/components/audio/styles";
import useMorseAudio, {
  type SoundPreset,
} from "~/client/components/audio/useMorseAudio";
import {
  getUnsupportedTextCharacters,
  normalizeMorseForDecoding,
  textToMorse,
} from "~/client/components/audio/morseUtils";

import {
  CopyIcon,
  LoopIcon,
  PauseIcon,
  PlayIcon,
  SaveIcon,
  SoundIcon,
  StopIcon,
  LightBulbIcon,
} from "~/client/assets/svg/Icons";

type SourceMode = "text" | "morse";

export default function MorseAudioTranslator() {
  const player = useMorseAudio();

  const [sourceMode, setSourceMode] = React.useState<SourceMode>("text");
  const [text, setText] = React.useState("sos help");
  const [morse, setMorse] = React.useState("... --- ...");
  const computedMorse = React.useMemo(() => textToMorse(text), [text]);

  const activeCode = React.useMemo(() => {
    return sourceMode === "text" ? computedMorse : morse;
  }, [sourceMode, computedMorse, morse]);

  const [copied, setCopied] = React.useState<null | "morse">(null);

  const [charWpm, setCharWpm] = React.useState<number>(18);
  const [farnsworthWpm, setFarnsworthWpm] = React.useState<number>(12);
  const [toneHz, setToneHz] = React.useState<number>(650);
  const [volume, setVolume] = React.useState<number>(0.75);
  const [preset, setPreset] = React.useState<SoundPreset>("cw_radio");

  const [attackMs, setAttackMs] = React.useState<number>(8);
  const [releaseMs, setReleaseMs] = React.useState<number>(12);
  const [repeat, setRepeat] = React.useState<boolean>(false);
  const [soundOn, setSoundOn] = React.useState<boolean>(true);
  const [flash, setFlash] = React.useState<boolean>(false);
  const [advancedOpen, setAdvancedOpen] = React.useState<boolean>(true);
  const [exportOpen, setExportOpen] = React.useState<boolean>(true);
  const [fileName, setFileName] = React.useState("morse-audio");
  const [sampleRate, setSampleRate] = React.useState<22050 | 44100 | 48000>(
    44100,
  );
  const [tailMs, setTailMs] = React.useState<number>(120);

  const [hydrated, setHydrated] = React.useState(false);
  const [isMobile, setIsMobile] = React.useState(false);

  // Load persisted settings
  React.useEffect(() => {
    setSourceMode((readStr("mw_audio_source", "text") as SourceMode) || "text");
    setText(readStr("mw_audio_text", "sos help"));
    setMorse(readStr("mw_audio_morse", "... --- ..."));

    setCharWpm(readNum("mw_audio_wpm", 18));
    setFarnsworthWpm(readNum("mw_audio_fwpm", 12));
    setToneHz(readNum("mw_audio_hz", 650));
    setVolume(readNum("mw_audio_vol", 0.75));
    setPreset(
      (readStr("mw_audio_preset", "cw_radio") as SoundPreset) || "cw_radio",
    );

    setAttackMs(readNum("mw_audio_attack", 8));
    setReleaseMs(readNum("mw_audio_release", 12));
    setRepeat(readBool("mw_audio_repeat", false));
    setSoundOn(readBool("mw_audio_sound", true));
    setFlash(readBool("mw_audio_flash", false));

    setAdvancedOpen(readBool("mw_audio_adv_open", true));
    setExportOpen(readBool("mw_audio_export_open", true));
    setFileName(readStr("mw_audio_filename", "morse-audio"));
    setSampleRate((readNum("mw_audio_sr", 44100) as any) || 44100);
    setTailMs(readNum("mw_audio_tail", 120));

    setHydrated(true);
  }, []);

  React.useEffect(() => {
    if (!hydrated) return;
    const mq = window.matchMedia?.("(max-width: 640px)");
    const apply = () => setIsMobile(!!mq?.matches);
    apply();
    if (!mq) return;
    try {
      mq.addEventListener("change", apply);
      return () => mq.removeEventListener("change", apply);
    } catch {
      mq.addListener?.(apply as any);
      return () => mq.removeListener?.(apply as any);
    }
  }, [hydrated]);

  // Live update audio settings during playback/paused
  React.useEffect(() => {
    if (!hydrated) return;
    const anyPlayer: any = player as any;
    if (!anyPlayer.setLiveOptions) return;

    anyPlayer.setLiveOptions({
      wpm: clampNum(charWpm, 5, 60),
      farnsworthWpm: clampNum(farnsworthWpm, 5, 60),
      hz: toneHz,
      volume,
      soundEnabled: soundOn,
      preset,
      repeat,
      flash,
      attackMs,
      releaseMs,
    });
  }, [
    hydrated,
    player,
    charWpm,
    farnsworthWpm,
    toneHz,
    volume,
    soundOn,
    preset,
    repeat,
    flash,
    attackMs,
    releaseMs,
  ]);

  // Persist settings as they change
  React.useEffect(() => {
    if (!hydrated) return;

    writeStr("mw_audio_source", sourceMode);
    writeStr("mw_audio_text", text);
    writeStr("mw_audio_morse", morse);

    writeNum("mw_audio_wpm", charWpm);
    writeNum("mw_audio_fwpm", farnsworthWpm);
    writeNum("mw_audio_hz", toneHz);
    writeNum("mw_audio_vol", volume);
    writeStr("mw_audio_preset", preset);

    writeNum("mw_audio_attack", attackMs);
    writeNum("mw_audio_release", releaseMs);
    writeBool("mw_audio_repeat", repeat);
    writeBool("mw_audio_sound", soundOn);
    writeBool("mw_audio_flash", flash);

    writeBool("mw_audio_adv_open", advancedOpen);
    writeBool("mw_audio_export_open", exportOpen);
    writeStr("mw_audio_filename", fileName);
    writeNum("mw_audio_sr", sampleRate);
    writeNum("mw_audio_tail", tailMs);
  }, [
    hydrated,
    sourceMode,
    text,
    morse,
    charWpm,
    farnsworthWpm,
    toneHz,
    volume,
    preset,
    attackMs,
    releaseMs,
    repeat,
    soundOn,
    flash,
    advancedOpen,
    exportOpen,
    fileName,
    sampleRate,
    tailMs,
  ]);

  // Flash overlay (listens to morsewords:flash)
  React.useEffect(() => {
    if (!flash) return;

    const handler = (ev: Event) => {
      const detail = (ev as CustomEvent).detail as { ms?: number } | undefined;
      const ms = detail?.ms ?? 0;
      if (!ms) return;

      const el = document.getElementById("mw_flash_overlay");
      if (!el) return;

      el.classList.remove("opacity-0");
      el.classList.add("opacity-100");

      window.setTimeout(() => {
        el.classList.remove("opacity-100");
        el.classList.add("opacity-0");
      }, ms);
    };

    window.addEventListener("morsewords:flash", handler as any);
    return () => window.removeEventListener("morsewords:flash", handler as any);
  }, [flash]);

  const canPlay = !!activeCode.trim();
  const durationMs = React.useMemo(() => {
    if (!canPlay) return 0;
    return player.estimateDurationMs({
      code: activeCode,
      wpm: clampNum(charWpm, 5, 60),
      farnsworthWpm: clampNum(farnsworthWpm, 5, 60),
    });
  }, [player, activeCode, canPlay, charWpm, farnsworthWpm]);

  const unsupportedPlain = React.useMemo(
    () => getUnsupportedTextCharacters(text),
    [text],
  );

  const morseIssues = React.useMemo(() => {
    const issues: string[] = [];
    if (sourceMode !== "morse") return issues;
    if (!morse) return issues;

    const { invalidChars } = normalizeMorseForDecoding(morse);
    if (invalidChars.length) {
      issues.push(
        `Invalid character${invalidChars.length > 1 ? "s" : ""}: ${invalidChars.join(" ")}`,
      );
    }
    return issues;
  }, [sourceMode, morse]);

  const setFeedback = React.useCallback(
    (key: "sound" | "repeat" | "flash", next: boolean) => {
      const current = { sound: soundOn, repeat, flash };
      const updated = { ...current, [key]: next };

      if (key === "sound") setSoundOn(next);
      if (key === "repeat") setRepeat(next);
      if (key === "flash") setFlash(next);

      // If sound is turned off while playing, mute instantly via live options
      const anyPlayer: any = player as any;
      if (anyPlayer.setLiveOptions) {
        anyPlayer.setLiveOptions({ soundEnabled: updated.sound });
      }
    },
    [soundOn, repeat, flash, player],
  );

  const handleCopyMorse = async () => {
    const s = activeCode.trim();
    if (!s) return;
    try {
      await navigator.clipboard.writeText(s);
      setCopied("morse");
      setTimeout(() => setCopied(null), 1200);
    } catch {
      // ignore
    }
  };

  const handlePlay = async () => {
    if (!canPlay) return;

    await player.play({
      code: activeCode,
      wpm: clampNum(charWpm, 5, 60),
      farnsworthWpm: clampNum(farnsworthWpm, 5, 60),
      hz: toneHz,
      volume,
      soundEnabled: soundOn,
      preset,
      repeat,
      flash,
      attackMs,
      releaseMs,
    });
  };

  const handleExportWav = async () => {
    if (!canPlay) return;
    if (!soundOn) return;

    const safeBase = sanitizeFileBase(fileName || "morse-audio");
    try {
      const blob = await player.renderWav({
        code: activeCode,
        wpm: clampNum(charWpm, 5, 60),
        farnsworthWpm: clampNum(farnsworthWpm, 5, 60),
        hz: toneHz,
        volume,
        soundEnabled: true,
        preset,
        attackMs,
        releaseMs,
        sampleRate,
        tailMs,
      });

      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `${safeBase}.wav`;
      a.click();
      setTimeout(() => URL.revokeObjectURL(url), 2000);
    } catch {
      // ignore
    }
  };

  return (
    <div style={styles.page}>
      {flash && (
        <div
          id="mw_flash_overlay"
          className="fixed inset-0 bg-white opacity-0 pointer-events-none transition-opacity duration-75"
        />
      )}

      <section className="py-7">
        <div className="max-w-[1120px] mx-auto px-4">
          <div className="flex flex-col gap-3">
            <h1 className="text-3xl sm:text-4xl font-extrabold text-neutral-900">
              Morse Audio Generator
            </h1>
            <p className="text-gray-700">
              Convert text or Morse into audio. Adjust speed, pitch, waveform,
              and export a WAV file.
            </p>

            <div className="mt-4 bg-white border border-gray-200 rounded-2xl p-4 sm:p-6 shadow-sm">
              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={() => setSourceMode("text")}
                  className={`px-3 py-2 rounded-xl font-semibold border cursor-pointer active:scale-95 transition ${
                    sourceMode === "text"
                      ? "border-neutral-900 bg-neutral-900 text-sky-200 hover:bg-neutral-800 hover:text-white"
                      : "border-gray-200 bg-white text-gray-700 hover:bg-gray-50"
                  }`}
                >
                  Text to Morse audio
                </button>
                <button
                  type="button"
                  onClick={() => setSourceMode("morse")}
                  className={`px-3 py-2 rounded-xl font-semibold border cursor-pointer active:scale-95 transition ${
                    sourceMode === "morse"
                      ? "border-neutral-900 bg-neutral-900 text-sky-200 hover:bg-neutral-800 hover:text-white"
                      : "border-gray-200 bg-white text-gray-700 hover:bg-gray-50"
                  }`}
                >
                  Morse to audio
                </button>

                <span className="ml-auto text-xs text-gray-500">
                  {player.isSupported ? (
                    <>Est. time: {formatMs(durationMs).toString()}</>
                  ) : (
                    <span className="text-gray-500">
                      Audio unavailable in this browser
                    </span>
                  )}
                </span>
              </div>

              <div className="grid gap-4 mt-4">
                <div>
                  <label htmlFor="mw_audio_source" className="font-semibold">
                    {sourceMode === "text" ? "Message (Text)" : "Morse input"}
                  </label>

                  {sourceMode === "text" ? (
                    <>
                      <textarea
                        id="mw_audio_source"
                        className="w-full mt-2 border rounded-md p-3 font-mono min-h-[11rem] resize-y outline-sky-500 border-sky-500"
                        value={text}
                        onChange={(e) => setText(e.target.value)}
                        placeholder="Example: Hello world"
                        autoCapitalize="characters"
                        autoCorrect="off"
                        spellCheck={false}
                      />
                      <div className="mt-2 flex flex-wrap items-center gap-2">
                        <button
                          type="button"
                          onClick={() =>
                            setText(isMobile ? "I love Morse code" : "sos help")
                          }
                          className="px-3 py-1.5 rounded-xl border border-gray-200 hover:bg-gray-50 font-semibold text-sm cursor-pointer active:scale-95 transition"
                        >
                          Use example
                        </button>
                        {!isMobile && (
                          <button
                            type="button"
                            onClick={() => setText("I love Morse code")}
                            className="px-3 py-1.5 rounded-xl border border-gray-200 hover:bg-gray-50 font-semibold text-sm cursor-pointer active:scale-95 transition"
                          >
                            I love Morse code
                          </button>
                        )}
                        <button
                          type="button"
                          onClick={() => setText("")}
                          className="ml-auto px-3 py-1.5 rounded-xl border border-gray-200 hover:bg-gray-50 font-semibold text-sm cursor-pointer active:scale-95 transition"
                        >
                          Clear output
                        </button>
                      </div>

                      {Object.keys(unsupportedPlain).length > 0 && (
                        <p className="mt-2 text-xs text-amber-600">
                          Unsupported characters are ignored:{" "}
                          {Object.entries(unsupportedPlain)
                            .map(([ch, n]) => `${ch}×${n}`)
                            .join(", ")}
                        </p>
                      )}
                    </>
                  ) : (
                    <>
                      <textarea
                        id="mw_audio_source"
                        className="w-full mt-2 border rounded-md p-3 font-mono min-h-[11rem] resize-y outline-sky-500 border-sky-500"
                        value={morse}
                        onChange={(e) => setMorse(e.target.value)}
                        placeholder="Example: ... --- ..."
                        autoCapitalize="off"
                        autoCorrect="off"
                        spellCheck={false}
                      />
                      <div className="mt-2 flex flex-wrap items-center gap-2">
                        <button
                          type="button"
                          onClick={() => setMorse("... --- ...")}
                          className="px-3 py-1.5 rounded-xl border border-gray-200 hover:bg-gray-50 font-semibold text-sm cursor-pointer active:scale-95 transition"
                        >
                          Use example
                        </button>
                        <button
                          type="button"
                          onClick={() => setMorse("")}
                          className="ml-auto px-3 py-1.5 rounded-xl border border-gray-200 hover:bg-gray-50 font-semibold text-sm cursor-pointer active:scale-95 transition"
                        >
                          Clear output
                        </button>
                      </div>

                      {morseIssues.length > 0 && (
                        <p className="mt-2 text-xs text-amber-600">
                          {morseIssues.join(" ")}
                        </p>
                      )}
                    </>
                  )}
                </div>
              </div>

              <div className="flex items-center gap-2 mt-4">
                <button
                  onClick={handleCopyMorse}
                  disabled={!canPlay}
                  className={`inline-flex items-center gap-2 px-3 py-2 cursor-pointer rounded-xl font-semibold active:scale-95 transition border ${
                    canPlay
                      ? "border-gray-300 text-gray-700 hover:bg-gray-50"
                      : "border-gray-200 text-gray-400 cursor-not-allowed"
                  }`}
                >
                  <CopyIcon size={18} title="Copy Morse" />
                  <span>Copy Morse</span>
                </button>
                {copied === "morse" && (
                  <span className="text-sm text-green-600">Copied</span>
                )}
                <span className="ml-auto text-xs text-gray-500">
                  3 spaces = letters, 7 spaces = words, “/” = word break
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 mt-3">
                <button
                  onClick={() => {
                    if (player.state === "idle") {
                      handlePlay();
                    } else if (player.state === "playing") {
                      player.pause();
                    } else if (player.state === "paused") {
                      player.resume();
                    }
                  }}
                  disabled={
                    player.state === "playing"
                      ? !player.isSupported
                      : !canPlay || !player.isSupported
                  }
                  className={`flex justify-center items-center gap-2 px-3 py-2 rounded-xl font-semibold cursor-pointer active:scale-95 transition ${
                    player.state === "playing"
                      ? player.isSupported
                        ? "border border-neutral-900 text-neutral-900 hover:bg-gray-50"
                        : "border border-gray-200 text-gray-400 cursor-not-allowed"
                      : canPlay && player.isSupported
                        ? "bg-neutral-900 text-sky-200 hover:bg-neutral-800 hover:text-white"
                        : "bg-gray-100 text-gray-400 cursor-not-allowed"
                  }`}
                >
                  {player.state === "playing" ? (
                    <PauseIcon size={22} title="Pause audio" />
                  ) : (
                    <PlayIcon
                      size={22}
                      title={
                        player.state === "paused"
                          ? "Resume audio"
                          : "Play audio"
                      }
                    />
                  )}
                  <span>
                    {player.state === "playing"
                      ? "Pause"
                      : player.state === "paused"
                        ? "Resume"
                        : "Play"}
                  </span>
                </button>

                <button
                  onClick={player.stop}
                  disabled={!player.isSupported || player.state === "idle"}
                  className={`flex justify-center items-center gap-2 px-3 py-2 rounded-xl font-semibold cursor-pointer active:scale-95 transition border ${
                    player.isSupported && player.state !== "idle"
                      ? "border-gray-300 text-gray-700 hover:bg-gray-50"
                      : "border-gray-200 text-gray-400 cursor-not-allowed"
                  }`}
                >
                  <StopIcon size={22} title="Stop audio" />
                  <span>Stop</span>
                </button>

                <button
                  onClick={handleExportWav}
                  disabled={!canPlay || !soundOn}
                  className={`flex justify-center items-center gap-2 px-3 py-2 rounded-xl font-semibold cursor-pointer active:scale-95 transition border ${
                    canPlay && soundOn
                      ? "border-gray-300 text-gray-700 hover:bg-gray-50"
                      : "border-gray-200 text-gray-400 cursor-not-allowed"
                  }`}
                >
                  <SaveIcon size={22} title="Export WAV" />
                  <span>Export WAV</span>
                </button>
              </div>
            </div>

            <div className="border border-gray-200 rounded-2xl p-4 bg-white mt-4">
              <div className="flex items-center justify-between gap-2">
                <h2 className="text-base font-bold text-neutral-900">
                  Audio controls
                </h2>
                <span className="text-sm text-gray-600">
                  {player.isSupported
                    ? player.state === "idle"
                      ? "Ready"
                      : player.state === "playing"
                        ? "Playing"
                        : "Paused"
                    : "Unavailable"}
                </span>
              </div>

              <div className="mt-4 grid sm:grid-cols-2 gap-4">
                <SliderRow
                  label="Character speed"
                  value={charWpm}
                  min={5}
                  max={60}
                  step={1}
                  unit="WPM"
                  onChange={setCharWpm}
                />
                <SliderRow
                  label="Farnsworth spacing"
                  value={farnsworthWpm}
                  min={5}
                  max={60}
                  step={1}
                  unit="WPM"
                  onChange={setFarnsworthWpm}
                  help="Slower spacing, same character speed"
                />
                <SliderRow
                  label="Pitch"
                  value={toneHz}
                  min={200}
                  max={1600}
                  step={10}
                  unit="Hz"
                  onChange={setToneHz}
                  disabled={!soundOn || preset === "sounder"}
                />
                <SliderRow
                  label="Volume"
                  value={Math.round(volume * 100)}
                  min={0}
                  max={100}
                  step={1}
                  unit="%"
                  onChange={(v) => setVolume(v / 100)}
                  disabled={!soundOn}
                />
              </div>

              {advancedOpen && (
                <div className="mt-4 border-t border-gray-100 pt-4">
                  <div className="grid sm:grid-cols-2 gap-4">
                    <div>
                      <label className="text-sm font-semibold text-gray-700">
                        Preset
                      </label>
                      <select
                        value={preset}
                        onChange={(e) =>
                          setPreset(e.target.value as SoundPreset)
                        }
                        className="mt-2 w-full rounded-xl border border-gray-200 bg-white px-3 py-2 font-semibold cursor-pointer hover:bg-gray-50"
                      >
                        <option value="cw_radio">CW (Radio)</option>
                        <option value="sine">Sine</option>
                        <option value="square">Square</option>
                        <option value="triangle">Triangle</option>
                        <option value="sawtooth">Sawtooth</option>
                        <option value="sounder">Telegraph sounder</option>
                      </select>
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <SliderRow
                        label="Attack"
                        value={attackMs}
                        min={0}
                        max={40}
                        step={1}
                        unit="ms"
                        onChange={setAttackMs}
                        disabled={!soundOn || preset === "sounder"}
                        help="Softens clicks at the start."
                      />
                      <SliderRow
                        label="Release"
                        value={releaseMs}
                        min={0}
                        max={80}
                        step={1}
                        unit="ms"
                        onChange={setReleaseMs}
                        disabled={!soundOn || preset === "sounder"}
                        help="Softens clicks at the end."
                      />
                    </div>
                  </div>

                  <div className="mt-4 flex flex-wrap gap-2">
                    <TogglePill
                      label="Sound"
                      checked={soundOn}
                      onChange={(v) => setFeedback("sound", v)}
                      icon={<SoundIcon size={16} title="Sound" />}
                    />
                    <TogglePill
                      label="Repeat"
                      checked={repeat}
                      onChange={(v) => setFeedback("repeat", v)}
                      icon={<LoopIcon size={16} title="Repeat" />}
                    />
                    <TogglePill
                      label="Flash"
                      checked={flash}
                      onChange={(v) => setFeedback("flash", v)}
                      icon={<LightBulbIcon size={16} title="Flash" />}
                    />
                  </div>

                  {flash && (
                    <div className="mt-3 rounded-2xl border border-amber-200 bg-amber-50 p-3 text-sm text-amber-900">
                      <div className="font-bold">Strobe warning</div>
                      <div className="mt-1">
                        Flashing light may trigger seizures for people with
                        photosensitive epilepsy. Disable Flash if you are
                        unsure.
                      </div>
                    </div>
                  )}
                </div>
              )}

              <div className="mt-4">
                <button
                  onClick={() => setAdvancedOpen((v) => !v)}
                  className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-3 py-2 rounded-xl border border-gray-200 hover:bg-gray-50 cursor-pointer active:scale-95 transition font-semibold"
                >
                  {advancedOpen ? "Hide advanced" : "Show advanced"}
                </button>
              </div>

              {exportOpen && (
                <div className="mt-4 border-t border-gray-100 pt-4">
                  <div className="grid sm:grid-cols-2 gap-4">
                    <div>
                      <label className="text-sm font-semibold text-gray-700">
                        File name
                      </label>
                      <input
                        value={fileName}
                        onChange={(e) => setFileName(e.target.value)}
                        className="mt-2 w-full rounded-xl border border-gray-200 bg-white px-3 py-2 font-semibold"
                        placeholder="morse-audio"
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="text-sm font-semibold text-gray-700">
                          Sample rate
                        </label>
                        <select
                          value={sampleRate}
                          onChange={(e) =>
                            setSampleRate(Number(e.target.value) as any)
                          }
                          className="mt-2 w-full rounded-xl border border-gray-200 bg-white px-3 py-2 font-semibold cursor-pointer hover:bg-gray-50"
                        >
                          <option value={22050}>22050</option>
                          <option value={44100}>44100</option>
                          <option value={48000}>48000</option>
                        </select>
                      </div>

                      <SliderRow
                        label="Tail padding"
                        value={tailMs}
                        min={0}
                        max={400}
                        step={10}
                        unit="ms"
                        onChange={setTailMs}
                        help="Extra silence to avoid clipped tails."
                        disabled={!soundOn}
                      />
                    </div>
                  </div>

                  <div className="mt-4 flex flex-wrap gap-2">
                    <button
                      type="button"
                      onClick={handleExportWav}
                      disabled={!canPlay || !soundOn}
                      className={`inline-flex items-center gap-2 px-3 py-2 rounded-xl font-semibold cursor-pointer active:scale-95 transition border ${
                        canPlay && soundOn
                          ? "border-gray-300 text-gray-700 hover:bg-gray-50"
                          : "border-gray-200 text-gray-400 cursor-not-allowed"
                      }`}
                    >
                      <SaveIcon size={18} title="Export WAV" />
                      <span>Download WAV</span>
                    </button>
                  </div>
                </div>
              )}

              <div className="mt-4">
                <button
                  onClick={() => setExportOpen((v) => !v)}
                  className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-3 py-2 rounded-xl border border-gray-200 hover:bg-gray-50 cursor-pointer active:scale-95 transition font-semibold"
                >
                  {exportOpen ? "Hide export" : "Show export"}
                </button>
              </div>

              <p className="mt-4 text-xs text-gray-500">
                Audio is generated in your browser. Nothing is uploaded.
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

function TogglePill({
  label,
  checked,
  onChange,
  icon,
}: {
  label: string;
  checked: boolean;
  onChange: (v: boolean) => void;
  icon?: React.ReactNode;
}) {
  return (
    <button
      type="button"
      onClick={() => onChange(!checked)}
      className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-sm font-semibold border cursor-pointer active:scale-95 transition ${
        checked
          ? "border-neutral-900 bg-neutral-900 text-sky-200 hover:bg-neutral-800 hover:text-white"
          : "border-gray-200 bg-white text-gray-700 hover:bg-gray-50"
      }`}
      aria-pressed={checked}
    >
      {icon}
      <span>{label}</span>
    </button>
  );
}

function SliderRow({
  label,
  value,
  min,
  max,
  step,
  unit,
  onChange,
  help,
  disabled,
}: {
  label: string;
  value: number;
  min: number;
  max: number;
  step: number;
  unit: string;
  onChange: (v: number) => void;
  help?: string;
  disabled?: boolean;
}) {
  return (
    <div>
      <div className="flex items-baseline justify-between">
        <label className="text-sm font-semibold text-gray-700">{label}</label>
        <span className="text-sm text-gray-600">
          {value} {unit}
        </span>
      </div>
      {help && <p className="text-xs text-gray-500 mt-0.5">{help}</p>}
      <input
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        disabled={disabled}
        style={{ accentColor: "#38bdf8" }}
        className={`w-full mt-2 ${
          disabled ? "cursor-not-allowed opacity-60" : "cursor-pointer"
        } focus:outline-none focus:ring-2 focus:ring-sky-300 rounded-full`}
      />
    </div>
  );
}

function readNum(key: string, fallback: number) {
  if (typeof window === "undefined") return fallback;
  const raw = window.localStorage.getItem(key);
  const n = raw ? Number(raw) : NaN;
  return Number.isFinite(n) ? n : fallback;
}

function readBool(key: string, fallback: boolean) {
  if (typeof window === "undefined") return fallback;
  const raw = window.localStorage.getItem(key);
  if (raw === null) return fallback;
  if (raw === "1") return true;
  if (raw === "0") return false;
  if (raw === "true") return true;
  if (raw === "false") return false;
  return fallback;
}

function readStr(key: string, fallback: string) {
  if (typeof window === "undefined") return fallback;
  return window.localStorage.getItem(key) ?? fallback;
}

function writeNum(key: string, value: number) {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(key, String(value));
  } catch {
    // ignore
  }
}

function writeBool(key: string, value: boolean) {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(key, value ? "1" : "0");
  } catch {
    // ignore
  }
}

function writeStr(key: string, value: string) {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(key, value);
  } catch {
    // ignore
  }
}

function clampNum(n: number, min: number, max: number) {
  return Math.min(max, Math.max(min, n));
}

function formatMs(ms: number) {
  if (!ms || ms <= 0) return "0s";
  const s = Math.round(ms / 1000);
  if (s < 60) return `${s}s`;
  const m = Math.floor(s / 60);
  const r = s % 60;
  return `${m}m ${r}s`;
}

function sanitizeFileBase(name: string) {
  return (
    name
      .trim()
      .replace(/[\\/:*?"<>|]+/g, "-")
      .replace(/\s+/g, "-")
      .replace(/-+/g, "-")
      .replace(/^-|-$/g, "")
      .slice(0, 80) || "morse-audio"
  );
}
