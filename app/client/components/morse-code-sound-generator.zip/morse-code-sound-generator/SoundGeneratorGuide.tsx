import * as React from "react";

const useCases = [
  {
    title: "Make a clean Morse beep",
    body: "Use the sine or CW preset, keep pitch around 600 to 700 Hz, then adjust character speed until each dit and dah is easy to hear.",
  },
  {
    title: "Create a practice audio file",
    body: "Type the message, slow the Farnsworth spacing if you need more thinking time, then download the WAV file for repeat listening.",
  },
  {
    title: "Turn pasted Morse into sound",
    body: "Paste dots, dashes, spaces, or slash-separated word gaps. The generator turns that pattern into timed sound without uploading anything.",
  },
];

const presets = [
  {
    name: "CW radio tone",
    setting: "CW or sine, 550 to 750 Hz",
    use: "Best default for Morse code practice and clean listening.",
  },
  {
    name: "Beep generator sound",
    setting: "Square wave, 600 to 900 Hz",
    use: "Sharper electronic beep for games, puzzles, demos, and videos.",
  },
  {
    name: "Soft tone generator",
    setting: "Triangle wave, 500 to 700 Hz",
    use: "Less harsh tone for longer listening or slower beginner practice.",
  },
  {
    name: "Telegraph sounder style",
    setting: "Telegraph sounder preset",
    use: "Percussive click-like output when you want a more mechanical feel.",
  },
];

export default function SoundGeneratorGuide() {
  return (
    <>
      <section className="mt-8 bg-white border border-gray-200 rounded-2xl p-5 sm:p-8 shadow-sm">
        <div className="inline-flex items-center rounded-full border border-sky-200 bg-sky-50 px-3 py-1.5 text-sm font-extrabold text-sky-900">
          Sound maker guide
        </div>
        <h2 className="mt-4 text-3xl sm:text-4xl font-extrabold text-sky-900 tracking-tight">
          Morse code sound generator for beeps, tones, and audio files
        </h2>
        <p className="mt-3 text-base sm:text-lg text-gray-700 leading-relaxed">
          This page is built for people who want a Morse code sound generator, not just a visual translator. Type text or paste Morse code, hear the result as beeps, tune the tone, and export a WAV audio file you can use for practice tracks, lessons, puzzles, videos, or testing.
        </p>
        <p className="mt-3 text-base sm:text-lg text-gray-700 leading-relaxed">
          Use the controls above as a Morse code tone generator: speed changes the timing, pitch changes the beep frequency, waveform changes the character of the sound, and Farnsworth spacing gives learners more time between letters and words without making each symbol sloppy.
        </p>

        <div className="mt-6 grid gap-4 md:grid-cols-3">
          {useCases.map((item) => (
            <div key={item.title} className="rounded-2xl border border-sky-200 bg-sky-50 p-5">
              <h3 className="font-extrabold text-sky-900">{item.title}</h3>
              <p className="mt-2 text-gray-700 leading-relaxed">{item.body}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="mt-8 bg-white border border-gray-200 rounded-2xl p-5 sm:p-8 shadow-sm">
        <h2 className="text-2xl sm:text-3xl font-extrabold text-sky-900">
          Which Morse sound should you use?
        </h2>
        <p className="mt-3 text-gray-700 leading-relaxed">
          Most Morse code audio generators let you control speed and tone because the same message can sound very different depending on the waveform. Start clean, then make it sharper or softer only after the timing feels right.
        </p>

        <div className="mt-5 grid gap-4 md:grid-cols-2">
          {presets.map((preset) => (
            <article key={preset.name} className="rounded-2xl border border-gray-200 bg-gray-50 p-5">
              <h3 className="font-extrabold text-sky-900">{preset.name}</h3>
              <p className="mt-2 text-sm font-semibold text-neutral-900">{preset.setting}</p>
              <p className="mt-2 text-gray-700 leading-relaxed">{preset.use}</p>
            </article>
          ))}
        </div>
      </section>

      <section className="mt-8 bg-white border border-gray-200 rounded-2xl p-5 sm:p-8 shadow-sm">
        <h2 className="text-2xl sm:text-3xl font-extrabold text-sky-900">
          WAV export, MP3 intent, and practical audio workflow
        </h2>
        <div className="mt-4 space-y-4 text-gray-700 leading-relaxed">
          <p>
            The generator exports WAV because WAV is simple, reliable, and preserves the exact timing rendered by the browser. That matters for Morse code because tiny timing changes can make a practice file harder to copy.
          </p>
          <p>
            If you specifically need an MP3, export the WAV first and convert it in your audio editor, video editor, or operating system tool. Keeping the browser export as WAV avoids lossy compression during the Morse timing step.
          </p>
          <p>
            For a clean practice file, use a sine or CW tone, leave a small attack and release enabled, add tail padding, then download the WAV. For a sharper “beep generator” effect, switch to a square wave and raise the pitch slightly.
          </p>
        </div>
      </section>
    </>
  );
}
