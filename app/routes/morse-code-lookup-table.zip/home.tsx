import * as React from "react";
import type { Route } from "./+types/home";

import styles from "~/client/components/home/styles";
import TranslatorSectionsBasic from "~/client/components/home/TranslatorSectionsBasic";
import FaqSectionGeneric from "~/client/components/home/FaqSectionGeneric";
import JsonLdScript from "~/client/components/home/JsonLdScript";
import { morseToText, textToMorse } from "~/client/components/home/morseUtils";

export function meta({}: Route.MetaArgs) {
  return [
    {
      title:
        "Morse Code Translator | Text to Morse and Morse to Text | MorseWords",
    },
    {
      name: "description",
      content:
        "Free Morse code translator. Convert text to Morse code or decode Morse to text instantly. Supports letters, numbers, and common punctuation.",
    },
    {
      name: "keywords",
      content:
        "morse code translator, text to morse, morse to text, morse decoder, morse encoder",
    },
    { name: "robots", content: "index,follow" },
    { name: "theme-color", content: "#0b2447" },
  ];
}

export default function Home() {
  // Translator state (conversion logic stays in morseUtils)
  const [plainA, setPlainA] = React.useState("sos help");
  const morseA = React.useMemo(() => textToMorse(plainA), [plainA]);

  const [morseB, setMorseB] = React.useState("... --- ...");
  const textB = React.useMemo(() => morseToText(morseB), [morseB]);

  const baseUrl = "https://morsewords.com";
  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "WebApplication",
    name: "MorseWords Morse Code Translator",
    applicationCategory: "UtilityApplication",
    operatingSystem: "All",
    url: baseUrl + "/",
    description:
      "Browser-based Morse code translator for converting between text and Morse code.",
    offers: { "@type": "Offer", price: "0", priceCurrency: "USD" },
  };

  const faqItems = [
    {
      q: "What does this translator support?",
      a: "It supports A–Z, 0–9, and common punctuation. Unsupported characters are ignored in the output.",
    },
    {
      q: "How do I paste Morse code to decode it?",
      a: "Paste dots and dashes into the Morse input. Use 3 spaces between letters and 7 spaces between words for best decoding.",
    },
    {
      q: "Can I use / as a word separator?",
      a: "Yes. A slash is treated as a word separator when decoding.",
    },
    {
      q: "Why is spacing important for decoding?",
      a: "The decoder needs separators to know where one letter ends and the next begins. Three spaces separate letters and seven spaces separate words.",
    },
  ];

  return (
    <div style={styles.page}>
      <div style={styles.wrap}>
        <section className="mt-6">
          <h1 style={styles.h1}>Morse code translator</h1>
          <p>
            All-in-one Morse code translator & decoder: encode text into Morse, or decode Morse back to
            readable text.
          </p>
        </section>

        <TranslatorSectionsBasic
          plainA={plainA}
          setPlainA={setPlainA}
          morseA={morseA}
          morseB={morseB}
          textB={textB}
          setMorseB={setMorseB}
        />

        <section className="mt-6 bg-white border border-gray-200 rounded-2xl p-6 shadow-sm">
          <h2 className="text-2xl font-bold text-[#0b2447]">How it works</h2>
          <p style={styles.lead}>
            Use this Morse code translator to encode plain text into
            International Morse or decode Morse back to readable text in the
            same tool. Paste your input, copy the result, then listen with clean
            playback controls. Adjust speed, pitch, and volume, toggle repeat,
            and (on mobile) add optional light or vibration feedback. You can
            also save the audio as a WAV file or share a quick snapshot of a
            translation.
          </p>
          <p className="mt-3 text-gray-700 leading-relaxed">
            MorseWords converts between text and International Morse using a
            character map for letters, numbers, and common punctuation. For text
            to Morse, type or paste text and the tool outputs dots and dashes.
            For Morse to text, paste Morse using dots and dashes, separate
            letters with three spaces, and separate words with seven spaces. A
            slash is also treated as a word separator when decoding. If your
            input contains unsupported characters, they are ignored so the
            output stays readable. For audio, the player synthesizes dits and
            dahs using standard timing. Character speed controls the dit length,
            and Farnsworth (if enabled) slows only the spacing to make practice
            more comfortable. Use sound presets for different listening styles,
            and optionally enable screen flashes or vibration on mobile. When
            you need to export or send a result, save a WAV file or share a
            snapshot.
          </p>
        </section>

        <FaqSectionGeneric title="Translator FAQ" items={faqItems} />
      </div>

      <JsonLdScript jsonLd={jsonLd} />
    </div>
  );
}
