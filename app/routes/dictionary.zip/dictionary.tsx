import * as React from "react";
import type { Route } from "./+types/dictionary";

import styles from "~/client/components/home/styles";
import JsonLdScript from "~/client/components/home/JsonLdScript";
import DictionarySections from "~/client/components/dictionary/DictionarySections";

export function meta({}: Route.MetaArgs) {
  return [
    { title: "Morse Code Dictionary | Lookup Table (Copy + Filter) | MorseWords" },
    {
      name: "description",
      content:
        "Morse code dictionary for fast lookup. Filter letters, numbers, punctuation, prosigns, Q-codes, and common phrases. Tap to copy any pattern instantly.",
    },
    {
      name: "keywords",
      content:
        "morse code dictionary, morse code chart, morse lookup table, morse prosigns, morse q codes, cw abbreviations",
    },
    { name: "robots", content: "index,follow" },
    { name: "theme-color", content: "#0b2447" },
  ];
}

export default function DictionaryRoute() {
  const baseUrl = "https://morsewords.com";
  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "WebApplication",
    name: "MorseWords Morse Code Dictionary",
    applicationCategory: "UtilityApplication",
    operatingSystem: "All",
    url: baseUrl + "/dictionary",
    description:
      "Lookup table for Morse code characters, prosigns, Q-codes, and common phrases with copy controls and filtering.",
    offers: { "@type": "Offer", price: "0", priceCurrency: "USD" },
  };

  return (
    <div style={styles.page}>
      <div style={styles.wrap}>
        <DictionarySections />
      </div>

      <JsonLdScript jsonLd={jsonLd} />
    </div>
  );
}
